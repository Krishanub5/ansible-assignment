# Problem Statement
Setup custom ansible fact in managed nodes and configure packages according to the custom facts
