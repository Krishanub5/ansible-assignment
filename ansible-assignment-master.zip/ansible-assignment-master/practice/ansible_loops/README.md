# Problem Statement
Iterate a list of packages and install them

